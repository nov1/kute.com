<?php

require_once 'application/bootstrap.php';
