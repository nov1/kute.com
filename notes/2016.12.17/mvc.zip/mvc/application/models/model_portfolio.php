<?php

class Model_Portfolio extends Model
{
	
	public function get_data()
	{	
		var_dump($this->db);
		// Здесь мы просто сэмулируем реальные данные.
		
	
	}

}
