<?


const DB_NAME = "phpLearn";
const DB_HOST = "localhost";
const DB_PASSWD = "zenzen88";
const DB_USER = "phpLearn";



















?>